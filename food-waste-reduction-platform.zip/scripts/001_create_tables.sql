-- SaveServe Database Schema
-- Food waste reduction platform with role-based access control

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (for all user types)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('restaurant', 'individual', 'ngo', 'admin')),
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Restaurant profiles
CREATE TABLE restaurants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  restaurant_name VARCHAR(255) NOT NULL,
  address TEXT NOT NULL,
  city VARCHAR(100) NOT NULL,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  license_number VARCHAR(100),
  approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- NGO profiles
CREATE TABLE ngos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  ngo_name VARCHAR(255) NOT NULL,
  registration_number VARCHAR(100),
  address TEXT NOT NULL,
  city VARCHAR(100) NOT NULL,
  approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Food listings (only restaurants can create)
CREATE TABLE food_listings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
  food_name VARCHAR(255) NOT NULL,
  quantity VARCHAR(100) NOT NULL,
  food_type VARCHAR(50) NOT NULL CHECK (food_type IN ('cooked', 'baked', 'prepared')),
  prepared_at TIMESTAMP NOT NULL,
  consume_before TIMESTAMP NOT NULL,
  is_donation BOOLEAN DEFAULT true,
  discounted_price DECIMAL(10, 2),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'reserved', 'collected', 'expired', 'removed')),
  safety_verified BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT valid_expiry CHECK (consume_before > prepared_at)
);

-- Food requests/reservations
CREATE TABLE food_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  food_listing_id UUID REFERENCES food_listings(id) ON DELETE CASCADE,
  requester_id UUID REFERENCES users(id) ON DELETE CASCADE,
  requester_type VARCHAR(20) CHECK (requester_type IN ('individual', 'ngo')),
  quantity_requested VARCHAR(100),
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'collected', 'cancelled')),
  pickup_time TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Activity logs (for compliance and audit trails)
CREATE TABLE activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id UUID,
  details JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_food_listings_status ON food_listings(status);
CREATE INDEX idx_food_listings_consume_before ON food_listings(consume_before);
CREATE INDEX idx_food_listings_restaurant ON food_listings(restaurant_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
