import { requireAuth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { AdminDashboard } from "@/components/admin-dashboard"

export default async function AdminDashboardPage() {
  const user = await requireAuth(["admin"])

  if (!user) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <AdminDashboard user={user} />
    </div>
  )
}
