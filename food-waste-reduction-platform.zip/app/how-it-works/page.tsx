import { SiteHeader } from "@/components/site-header"
import { Card, CardContent } from "@/components/ui/card"
import { Building2, Search, Calendar, CheckCircle2, Shield, FileText } from "lucide-react"

export default function HowItWorksPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="container py-12 md:py-20">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">How SaveServe Works</h1>
              <p className="text-lg text-muted-foreground text-balance">
                A step-by-step guide to reducing food waste responsibly
              </p>
            </div>

            <div className="space-y-12">
              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    1
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Building2 className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Restaurants List Surplus Food</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Restaurants log into their secure dashboard and manually add surplus cooked food items. They enter
                      details like food name, quantity, preparation time, and safe consumption deadline.
                    </p>
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium mb-2">Safety Rules Enforced:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Only cooked/prepared food allowed</li>
                        <li>• Must set realistic expiry times</li>
                        <li>• System auto-removes expired items</li>
                        <li>• No manual override of safety rules</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    2
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Search className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Users Discover Food</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Anyone can browse available food on the public homepage without logging in. Food is displayed in
                      real-time with safety badges, time remaining, and restaurant information.
                    </p>
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium mb-2">Who Can Collect:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Individuals seeking affordable meals</li>
                        <li>• NGOs for bulk community distribution</li>
                        <li>• Food collection organizations</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    3
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Calendar className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Reserve & Schedule Pickup</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      After logging in, users can reserve food items and receive pickup details. NGOs can make bulk
                      requests for multiple items. All pickups are time-scheduled within the safety window.
                    </p>
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium mb-2">Pickup Process:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Receive restaurant contact details</li>
                        <li>• Get pickup time and location</li>
                        <li>• Bring own clean containers</li>
                        <li>• Verify food quality upon arrival</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    4
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <CheckCircle2 className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Collect & Consume Safely</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Recipients collect food at the scheduled time, inspect it visually, and consume or distribute it
                      within the safe time window. All collections are logged for transparency.
                    </p>
                    <div className="p-4 bg-destructive/10 border-destructive/20 border rounded-lg">
                      <p className="text-sm font-medium mb-2 text-destructive">Important Disclaimers:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Food is not for resale—personal consumption only</li>
                        <li>• Consumption responsibility lies with recipient</li>
                        <li>• Always check expiry time before consuming</li>
                        <li>• Platform acts as facilitator, not seller</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    5
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Shield className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Automated Safety Enforcement</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Behind the scenes, SaveServe continuously monitors all listings. Food is automatically removed
                      when expired, ensuring no unsafe items reach users. No one can override these rules.
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                    6
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <FileText className="h-6 w-6 text-primary" />
                      <h2 className="text-2xl font-bold">Compliance & Impact Tracking</h2>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      All actions are logged for audit trails. Restaurants get analytics on waste patterns, NGOs receive
                      distribution reports, and admins monitor platform-wide compliance.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2025 SaveServe. Reducing food waste, protecting public health.
          </p>
        </div>
      </footer>
    </div>
  )
}
