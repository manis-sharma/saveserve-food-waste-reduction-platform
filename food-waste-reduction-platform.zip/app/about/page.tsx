import { SiteHeader } from "@/components/site-header"
import { Card, CardContent } from "@/components/ui/card"
import { ShieldCheck, Heart, TrendingDown, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="container py-12 md:py-20">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">About SaveServe</h1>
              <p className="text-lg text-muted-foreground text-balance">
                Combining technology, food safety, and social impact to create a sustainable future
              </p>
            </div>

            <div className="space-y-8">
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    SaveServe is a food waste reduction platform that responsibly redistributes surplus cooked food from
                    restaurants to nearby individuals, NGOs, and food collection groups. We strictly maintain food
                    safety, transparency, and regulatory awareness while addressing the critical issues of food waste
                    and food insecurity.
                  </p>
                </CardContent>
              </Card>

              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardContent className="pt-6">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <ShieldCheck className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Safety First</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Automated safety rules ensure only fresh, time-tracked food is distributed. No manual overrides
                      allowed.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <TrendingDown className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Reduce Waste</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Every meal saved prevents environmental impact and reduces carbon emissions from food waste.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Heart className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Feed Communities</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Connect surplus food to those in need, supporting individuals and NGOs in addressing hunger.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Build Trust</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Transparent operations with audit trails, compliance logs, and regulatory awareness built-in.
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="pt-6">
                  <h2 className="text-2xl font-bold mb-4">How We Work</h2>
                  <div className="space-y-4 text-muted-foreground">
                    <p className="leading-relaxed">
                      SaveServe operates as a regulated digital platform that facilitates connections between food
                      donors (restaurants) and recipients (individuals and NGOs). We enforce strict time-based safety
                      rules automatically, ensuring all food is consumed within safe windows.
                    </p>
                    <p className="leading-relaxed">
                      Restaurants manage their listings through secure dashboards, but cannot override system safety
                      rules. Food is automatically removed when expired, and all transactions are logged for
                      transparency and compliance.
                    </p>
                    <p className="leading-relaxed">
                      We act as a facilitator, not a food seller. Consumption responsibility lies with recipients, and
                      all food is for personal consumption or direct distribution only—never for resale.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2025 SaveServe. Reducing food waste, protecting public health.
          </p>
        </div>
      </footer>
    </div>
  )
}
