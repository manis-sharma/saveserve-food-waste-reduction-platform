import { SiteHeader } from "@/components/site-header"
import { FoodCard } from "@/components/food-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getActiveFoodListings } from "@/lib/food-data"
import { getUserAction } from "./actions"
import Link from "next/link"
import { ShieldCheck, Clock, Building2, Heart, Users } from "lucide-react"

export default async function HomePage() {
  const activeFoods = getActiveFoodListings()
  const user = await getUserAction()

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container py-12 md:py-20">
          <div className="mx-auto max-w-4xl text-center space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <span className="text-muted-foreground">Live food availability - Updated in real-time</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-balance leading-tight">
              Reduce Food Waste, <span className="text-primary">Feed Communities</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground text-balance max-w-2xl mx-auto">
              Connect surplus food from restaurants to individuals and NGOs. Every meal saved is a step towards
              sustainability and zero hunger.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
              {!user && (
                <>
                  <Button size="lg" asChild>
                    <Link href="/register">Get Started Free</Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild>
                    <Link href="/login">Login</Link>
                  </Button>
                </>
              )}
              {user && (
                <Button size="lg" asChild>
                  <Link
                    href={
                      user.role === "restaurant"
                        ? "/restaurant/dashboard"
                        : user.role === "ngo"
                          ? "/ngo/dashboard"
                          : "/user/dashboard"
                    }
                  >
                    Go to Dashboard
                  </Link>
                </Button>
              )}
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap items-center justify-center gap-6 pt-8 text-sm">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                <span className="font-medium">Food Safety First</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                <span className="font-medium">Time Controlled</span>
              </div>
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                <span className="font-medium">Verified Restaurants</span>
              </div>
            </div>
          </div>
        </section>

        {/* Live Food Availability */}
        <section className="border-t bg-gradient-to-b from-background via-muted/20 to-background py-16 md:py-24">
          <div className="container">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12 gap-4">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-balance">Available Right Now</h2>
                <p className="text-muted-foreground mt-3 text-lg">
                  Fresh surplus food from verified restaurants - no login required to browse
                </p>
              </div>
              <Badge variant="secondary" className="text-base px-6 py-3 rounded-full w-fit shadow-md">
                {activeFoods.length} Active Listings
              </Badge>
            </div>

            {activeFoods.length > 0 ? (
              <div className="grid gap-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                {activeFoods.map((food) => (
                  <FoodCard key={food.id} food={food} showActions={!!user} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-card rounded-3xl border shadow-xl">
                <div className="mx-auto w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
                  <Clock className="h-10 w-10 text-muted-foreground" />
                </div>
                <p className="text-xl font-bold mb-2">No food available at the moment</p>
                <p className="text-muted-foreground text-lg">Check back soon for fresh listings!</p>
              </div>
            )}

            {!user && (
              <div className="mt-16 text-center bg-gradient-to-br from-primary/5 via-background to-primary/5 rounded-3xl border border-primary/20 p-10 shadow-xl">
                <h3 className="text-2xl md:text-3xl font-bold mb-3">Ready to make an impact?</h3>
                <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                  Create an account to reserve food, reduce waste, and help feed your community
                </p>
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <Button
                    size="lg"
                    className="rounded-2xl px-8 py-6 text-base font-bold shadow-lg hover:shadow-xl"
                    asChild
                  >
                    <Link href="/register">Sign Up as Individual</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="rounded-2xl px-8 py-6 text-base font-bold shadow-lg hover:shadow-xl bg-background"
                    asChild
                  >
                    <Link href="/register?type=ngo">Register as NGO</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="rounded-2xl px-8 py-6 text-base font-bold shadow-lg hover:shadow-xl bg-background"
                    asChild
                  >
                    <Link href="/register?type=restaurant">Register Restaurant</Link>
                  </Button>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* How It Works */}
        <section className="container py-12 md:py-16">
          <h2 className="text-3xl font-bold text-center mb-12 text-balance">How SaveServe Works</h2>

          <div className="grid gap-8 md:grid-cols-3">
            <div className="text-center space-y-4">
              <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Building2 className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Restaurants List Food</h3>
              <p className="text-muted-foreground">
                Restaurants add surplus cooked food with preparation time and safe consumption window
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Community Discovers</h3>
              <p className="text-muted-foreground">
                Individuals and NGOs browse available food in real-time and reserve what they need
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Impact Created</h3>
              <p className="text-muted-foreground">
                Food waste reduced, hunger addressed, and communities strengthened through shared resources
              </p>
            </div>
          </div>
        </section>

        {/* Impact Stats */}
        <section className="border-t bg-primary/5 py-12 md:py-16">
          <div className="container">
            <div className="grid gap-8 md:grid-cols-3 text-center">
              <div className="space-y-2">
                <div className="text-4xl font-bold text-primary">2,500+</div>
                <div className="text-sm text-muted-foreground">Meals Saved</div>
              </div>
              <div className="space-y-2">
                <div className="text-4xl font-bold text-primary">150+</div>
                <div className="text-sm text-muted-foreground">Partner Restaurants</div>
              </div>
              <div className="space-y-2">
                <div className="text-4xl font-bold text-primary">85%</div>
                <div className="text-sm text-muted-foreground">Waste Reduction</div>
              </div>
            </div>
          </div>
        </section>

        {/* Safety Notice */}
        <section className="container py-12 md:py-16">
          <div className="mx-auto max-w-3xl rounded-lg border bg-card p-6 md:p-8">
            <div className="flex items-start gap-4">
              <ShieldCheck className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Food Safety & Compliance</h3>
                <p className="text-muted-foreground leading-relaxed">
                  SaveServe maintains strict food safety standards. All listed food is time-tracked, verified, and
                  automatically removed when expired. We act as a facilitator connecting donors and recipients -
                  consumption responsibility lies with the recipient. Food is not for resale.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2025 SaveServe. Reducing food waste, protecting public health.
          </p>
          <div className="flex items-center gap-6 text-sm">
            <Link href="/terms" className="text-muted-foreground hover:text-foreground">
              Terms
            </Link>
            <Link href="/privacy" className="text-muted-foreground hover:text-foreground">
              Privacy
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
