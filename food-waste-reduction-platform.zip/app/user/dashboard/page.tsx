import { requireAuth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { UserDashboard } from "@/components/user-dashboard"

export default async function UserDashboardPage() {
  const user = await requireAuth(["individual"])

  if (!user) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <UserDashboard user={user} />
    </div>
  )
}
