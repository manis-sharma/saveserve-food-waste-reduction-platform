"use server"

import { login as authLogin, logout as authLogout, getCurrentUser } from "@/lib/auth"
import { revalidatePath } from "next/cache"

export async function loginAction(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  const result = await authLogin(email, password)

  if (result.success) {
    revalidatePath("/")
    return { success: true, user: result.user }
  }

  return { success: false, error: result.error }
}

export async function logoutAction() {
  await authLogout()
  revalidatePath("/")
}

export async function getUserAction() {
  return await getCurrentUser()
}
