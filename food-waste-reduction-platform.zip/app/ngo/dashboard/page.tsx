import { requireAuth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { NGODashboard } from "@/components/ngo-dashboard"

export default async function NGODashboardPage() {
  const user = await requireAuth(["ngo"])

  if (!user) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <NGODashboard user={user} />
    </div>
  )
}
