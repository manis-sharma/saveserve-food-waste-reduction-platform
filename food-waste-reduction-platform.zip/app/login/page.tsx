import { SiteHeader } from "@/components/site-header"
import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1 flex items-center justify-center py-12">
        <LoginForm />
      </main>
    </div>
  )
}
