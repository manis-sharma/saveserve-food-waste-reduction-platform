export interface FoodListing {
  id: string
  restaurantId: string
  restaurantName: string
  foodName: string
  quantity: string
  foodType: "cooked" | "baked" | "prepared"
  preparedAt: Date
  consumeBefore: Date
  isDonation: boolean
  discountedPrice?: number
  status: "active" | "reserved" | "collected" | "expired" | "removed"
  safetyVerified: boolean
  createdAt: Date
}

export interface FoodRequest {
  id: string
  foodListingId: string
  requesterId: string
  requesterType: "individual" | "ngo"
  quantityRequested: string
  status: "pending" | "approved" | "collected" | "cancelled"
  pickupTime?: Date
  createdAt: Date
}

export interface Restaurant {
  id: string
  userId: string
  restaurantName: string
  address: string
  city: string
  latitude?: number
  longitude?: number
  licenseNumber?: string
  approved: boolean
}

export interface NGO {
  id: string
  userId: string
  ngoName: string
  registrationNumber?: string
  address: string
  city: string
  approved: boolean
}
