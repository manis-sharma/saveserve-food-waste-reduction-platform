import type { FoodListing } from "./types"

// Demo food listings (replace with database in production)
export function getDemoFoodListings(): FoodListing[] {
  const now = new Date()

  return [
    {
      id: "food-1",
      restaurantId: "rest-1",
      restaurantName: "Delicious Bites Restaurant",
      foodName: "Vegetable Biryani",
      quantity: "5 kg (serves 20)",
      foodType: "cooked",
      preparedAt: new Date(now.getTime() - 2 * 60 * 60 * 1000), // 2 hours ago
      consumeBefore: new Date(now.getTime() + 2 * 60 * 60 * 1000), // 2 hours from now
      isDonation: true,
      status: "active",
      safetyVerified: true,
      createdAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
    },
    {
      id: "food-2",
      restaurantId: "rest-1",
      restaurantName: "Delicious Bites Restaurant",
      foodName: "Grilled Chicken with Rice",
      quantity: "3 kg (serves 12)",
      foodType: "cooked",
      preparedAt: new Date(now.getTime() - 1 * 60 * 60 * 1000),
      consumeBefore: new Date(now.getTime() + 3 * 60 * 60 * 1000),
      isDonation: false,
      discountedPrice: 150,
      status: "active",
      safetyVerified: true,
      createdAt: new Date(now.getTime() - 1 * 60 * 60 * 1000),
    },
    {
      id: "food-3",
      restaurantId: "rest-2",
      restaurantName: "Healthy Eats Cafe",
      foodName: "Mixed Salad Bowl",
      quantity: "2 kg (serves 8)",
      foodType: "prepared",
      preparedAt: new Date(now.getTime() - 30 * 60 * 1000),
      consumeBefore: new Date(now.getTime() + 4 * 60 * 60 * 1000),
      isDonation: true,
      status: "active",
      safetyVerified: true,
      createdAt: new Date(now.getTime() - 30 * 60 * 1000),
    },
    {
      id: "food-4",
      restaurantId: "rest-3",
      restaurantName: "Pasta Paradise",
      foodName: "Marinara Pasta",
      quantity: "4 kg (serves 16)",
      foodType: "cooked",
      preparedAt: new Date(now.getTime() - 3 * 60 * 60 * 1000),
      consumeBefore: new Date(now.getTime() + 1 * 60 * 60 * 1000),
      isDonation: true,
      status: "active",
      safetyVerified: true,
      createdAt: new Date(now.getTime() - 3 * 60 * 60 * 1000),
    },
    {
      id: "food-5",
      restaurantId: "rest-2",
      restaurantName: "Healthy Eats Cafe",
      foodName: "Fresh Sandwiches",
      quantity: "15 pieces",
      foodType: "prepared",
      preparedAt: new Date(now.getTime() - 45 * 60 * 1000),
      consumeBefore: new Date(now.getTime() + 3 * 60 * 60 * 1000),
      isDonation: false,
      discountedPrice: 80,
      status: "active",
      safetyVerified: true,
      createdAt: new Date(now.getTime() - 45 * 60 * 1000),
    },
  ]
}

// Filter active food listings (safety checks)
export function getActiveFoodListings(): FoodListing[] {
  const now = new Date()
  return getDemoFoodListings().filter(
    (food) => food.status === "active" && food.consumeBefore > now && food.safetyVerified,
  )
}

// Auto-expire listings
export function checkAndExpireListings(listings: FoodListing[]): FoodListing[] {
  const now = new Date()
  return listings.map((food) => {
    if (food.consumeBefore <= now && food.status === "active") {
      return { ...food, status: "expired" as const }
    }
    return food
  })
}
