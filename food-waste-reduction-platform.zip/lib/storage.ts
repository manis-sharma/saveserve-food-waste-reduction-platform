"use client"

import type { FoodListing } from "./types"

// Client-side storage for demo purposes
export function saveFoodListings(listings: FoodListing[]): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("saveserve_listings", JSON.stringify(listings))
  }
}

export function loadFoodListings(): FoodListing[] {
  if (typeof window === "undefined") return []

  const stored = localStorage.getItem("saveserve_listings")
  if (!stored) return []

  try {
    const listings = JSON.parse(stored)
    // Parse date strings back to Date objects
    return listings.map((l: any) => ({
      ...l,
      preparedAt: new Date(l.preparedAt),
      consumeBefore: new Date(l.consumeBefore),
      createdAt: new Date(l.createdAt),
    }))
  } catch {
    return []
  }
}
