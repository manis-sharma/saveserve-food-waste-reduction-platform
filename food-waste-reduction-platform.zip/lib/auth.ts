"use server"

import { cookies } from "next/headers"

export type UserRole = "restaurant" | "individual" | "ngo" | "admin"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  verified: boolean
}

// Demo user storage (replace with database in production)
const DEMO_USERS: Record<string, { password: string; user: User }> = {
  "restaurant@demo.com": {
    password: "demo123",
    user: {
      id: "rest-1",
      email: "restaurant@demo.com",
      name: "Delicious Bites Restaurant",
      role: "restaurant",
      verified: true,
    },
  },
  "user@demo.com": {
    password: "demo123",
    user: {
      id: "user-1",
      email: "user@demo.com",
      name: "John Doe",
      role: "individual",
      verified: true,
    },
  },
  "ngo@demo.com": {
    password: "demo123",
    user: {
      id: "ngo-1",
      email: "ngo@demo.com",
      name: "Food Relief NGO",
      role: "ngo",
      verified: true,
    },
  },
}

export async function login(
  email: string,
  password: string,
): Promise<{ success: boolean; user?: User; error?: string }> {
  const demoUser = DEMO_USERS[email]

  if (!demoUser || demoUser.password !== password) {
    return { success: false, error: "Invalid credentials" }
  }

  // Set session cookie
  const cookieStore = await cookies()
  cookieStore.set("session", JSON.stringify(demoUser.user), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  })

  return { success: true, user: demoUser.user }
}

export async function logout(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete("session")
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies()
  const session = cookieStore.get("session")

  if (!session) {
    return null
  }

  try {
    return JSON.parse(session.value)
  } catch {
    return null
  }
}

export async function requireAuth(allowedRoles?: UserRole[]): Promise<User> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("Unauthorized")
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    throw new Error("Forbidden")
  }

  return user
}
