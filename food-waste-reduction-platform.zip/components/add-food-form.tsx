"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { FoodListing } from "@/lib/types"
import { AlertCircle } from "lucide-react"

interface AddFoodFormProps {
  onSubmit: (food: Omit<FoodListing, "id" | "restaurantId" | "restaurantName" | "createdAt">) => void
  onCancel: () => void
}

export function AddFoodForm({ onSubmit, onCancel }: AddFoodFormProps) {
  const [foodType, setFoodType] = useState<"cooked" | "baked" | "prepared">("cooked")
  const [isDonation, setIsDonation] = useState(true)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError("")

    const formData = new FormData(e.currentTarget)

    const preparedAt = new Date(formData.get("preparedAt") as string)
    const consumeBefore = new Date(formData.get("consumeBefore") as string)
    const now = new Date()

    // Validation
    if (preparedAt > now) {
      setError("Preparation time cannot be in the future")
      return
    }

    if (consumeBefore <= preparedAt) {
      setError("Consumption deadline must be after preparation time")
      return
    }

    if (consumeBefore <= now) {
      setError("Consumption deadline must be in the future")
      return
    }

    const food: Omit<FoodListing, "id" | "restaurantId" | "restaurantName" | "createdAt"> = {
      foodName: formData.get("foodName") as string,
      quantity: formData.get("quantity") as string,
      foodType,
      preparedAt,
      consumeBefore,
      isDonation,
      discountedPrice: isDonation ? undefined : Number.parseFloat(formData.get("discountedPrice") as string),
      status: "active",
      safetyVerified: true,
    }

    onSubmit(food)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="foodName">Food Name *</Label>
          <Input id="foodName" name="foodName" placeholder="e.g., Vegetable Biryani" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity *</Label>
          <Input id="quantity" name="quantity" placeholder="e.g., 5 kg (serves 20)" required />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="foodType">Food Type *</Label>
        <Select value={foodType} onValueChange={(v) => setFoodType(v as any)} required>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cooked">Cooked (hot meal)</SelectItem>
            <SelectItem value="baked">Baked (bread, pastries)</SelectItem>
            <SelectItem value="prepared">Prepared (cold items, salads)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="preparedAt">Prepared At *</Label>
          <Input
            id="preparedAt"
            name="preparedAt"
            type="datetime-local"
            max={new Date().toISOString().slice(0, 16)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="consumeBefore">Consume Before *</Label>
          <Input
            id="consumeBefore"
            name="consumeBefore"
            type="datetime-local"
            min={new Date().toISOString().slice(0, 16)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="listingType">Listing Type *</Label>
        <Select value={isDonation ? "donation" : "discounted"} onValueChange={(v) => setIsDonation(v === "donation")}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="donation">Free Donation</SelectItem>
            <SelectItem value="discounted">Discounted Price</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!isDonation && (
        <div className="space-y-2">
          <Label htmlFor="discountedPrice">Discounted Price (Rs) *</Label>
          <Input id="discountedPrice" name="discountedPrice" type="number" min="0" step="0.01" required />
        </div>
      )}

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1">
          Add Listing
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
