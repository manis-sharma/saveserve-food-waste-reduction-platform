import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ShieldCheck, Clock, AlertTriangle, ThermometerSun } from "lucide-react"

export function SafetyGuidelines() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            Food Safety Guidelines
          </CardTitle>
          <CardDescription>Important information to ensure safe food consumption</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> All food on SaveServe is donated/discounted surplus food. By accepting food,
              you acknowledge responsibility for safe consumption and agree that food is not for resale.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Clock className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Check Expiry Times</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Always verify the "Consume Before" time. Never consume food past its listed expiry. The system
                  automatically removes expired items, but double-check before pickup.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <ThermometerSun className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Temperature & Storage</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Hot food should be consumed immediately or refrigerated within 2 hours. Cold items should remain
                  chilled. Bring insulated bags for transport if needed.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Visual Inspection</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Inspect food upon pickup. Check for proper appearance, smell, and temperature. If anything seems off,
                  politely decline and report to the restaurant.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Know Your Allergies</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  If you have food allergies, always verify ingredients with the restaurant before pickup. SaveServe
                  cannot guarantee allergen-free food.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-accent/20 bg-accent/5">
        <CardHeader>
          <CardTitle className="text-base">Platform Responsibility</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p className="text-muted-foreground leading-relaxed">
            SaveServe acts as a facilitator connecting food donors and recipients. We enforce time-based safety rules
            and verification, but consumption responsibility lies with you.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            <strong>Not for resale:</strong> All food obtained through SaveServe is for personal consumption or direct
            distribution only. Reselling food is strictly prohibited.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>• Arrive on time for your reservation</li>
            <li>• Bring your own clean containers</li>
            <li>• Consume or refrigerate food immediately</li>
            <li>• Report any issues to both restaurant and platform</li>
            <li>• Be courteous to restaurant staff</li>
            <li>• Share feedback to improve the system</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
