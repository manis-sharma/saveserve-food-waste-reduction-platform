"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { FoodRequest, FoodListing } from "@/lib/types"
import { Calendar, MapPin, Users, Download } from "lucide-react"

interface NGODistributionLogsProps {
  requests: FoodRequest[]
  listings: FoodListing[]
}

export function NGODistributionLogs({ requests, listings }: NGODistributionLogsProps) {
  const handleDownloadLog = () => {
    // Generate CSV for download
    const csvContent = [
      ["Date", "Food Item", "Restaurant", "Quantity", "Collection Time", "Status"],
      ...requests.map((request) => {
        const food = listings.find((l) => l.id === request.foodListingId)
        return [
          request.createdAt.toLocaleDateString(),
          food?.foodName || "N/A",
          food?.restaurantName || "N/A",
          request.quantityRequested,
          request.pickupTime?.toLocaleString() || "N/A",
          request.status,
        ]
      }),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `distribution-log-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
          <p>No distribution records yet.</p>
          <p className="text-sm mt-2">Collected food will appear here for tracking.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Distribution Records</CardTitle>
              <CardDescription>Compliance-ready logs for audits and reporting</CardDescription>
            </div>
            <Button onClick={handleDownloadLog} variant="outline" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {requests.map((request) => {
              const food = listings.find((l) => l.id === request.foodListingId)
              if (!food) return null

              return (
                <Card key={request.id}>
                  <CardContent className="py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold">{food.foodName}</h4>
                          <Badge variant="secondary" className="bg-primary/10 text-primary">
                            Collected
                          </Badge>
                        </div>

                        <p className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {food.restaurantName}
                        </p>

                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {request.quantityRequested}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Collected:{" "}
                            {request.pickupTime?.toLocaleString("en-US", {
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-base">Record Keeping</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• All collection and distribution records are logged for transparency</p>
          <p>• Export logs for regulatory compliance and audit purposes</p>
          <p>• Records include timestamps, quantities, and source information</p>
          <p>• Data is stored securely and accessible for inspection</p>
        </CardContent>
      </Card>
    </div>
  )
}
