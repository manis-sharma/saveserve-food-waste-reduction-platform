"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AvailableFoodGrid } from "./available-food-grid"
import { UserReservations } from "./user-reservations"
import { SafetyGuidelines } from "./safety-guidelines"
import type { User } from "@/lib/auth"
import type { FoodListing, FoodRequest } from "@/lib/types"
import { loadFoodListings } from "@/lib/storage"
import { getActiveFoodListings } from "@/lib/food-data"
import { Search, History, ShieldCheck } from "lucide-react"

interface UserDashboardProps {
  user: User
}

export function UserDashboard({ user }: UserDashboardProps) {
  const [listings, setListings] = useState<FoodListing[]>([])
  const [reservations, setReservations] = useState<FoodRequest[]>([])

  useEffect(() => {
    // Load active listings
    const stored = loadFoodListings()
    if (stored.length > 0) {
      const active = stored.filter((l) => {
        const now = new Date()
        return l.status === "active" && l.consumeBefore > now && l.safetyVerified
      })
      setListings(active)
    } else {
      setListings(getActiveFoodListings())
    }

    // Load user reservations from localStorage
    const storedReservations = localStorage.getItem(`reservations_${user.id}`)
    if (storedReservations) {
      try {
        const parsed = JSON.parse(storedReservations)
        setReservations(
          parsed.map((r: any) => ({
            ...r,
            pickupTime: r.pickupTime ? new Date(r.pickupTime) : undefined,
            createdAt: new Date(r.createdAt),
          })),
        )
      } catch {
        setReservations([])
      }
    }
  }, [user.id])

  const handleReserve = (food: FoodListing) => {
    const reservation: FoodRequest = {
      id: `req-${Date.now()}`,
      foodListingId: food.id,
      requesterId: user.id,
      requesterType: "individual",
      quantityRequested: food.quantity,
      status: "approved",
      pickupTime: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      createdAt: new Date(),
    }

    const updatedReservations = [...reservations, reservation]
    setReservations(updatedReservations)
    localStorage.setItem(`reservations_${user.id}`, JSON.stringify(updatedReservations))
  }

  const pendingReservations = reservations.filter((r) => r.status === "pending" || r.status === "approved")
  const completedReservations = reservations.filter((r) => r.status === "collected")

  return (
    <main className="flex-1 py-8">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {user.name}</h1>
          <p className="text-muted-foreground">Discover and collect surplus food from nearby restaurants</p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Available Now</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{listings.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Food items near you</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Your Reservations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{pendingReservations.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Active pickups</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Collected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{completedReservations.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Meals saved</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="discover" className="space-y-6">
          <TabsList>
            <TabsTrigger value="discover" className="gap-2">
              <Search className="h-4 w-4" />
              Discover Food
            </TabsTrigger>
            <TabsTrigger value="reservations" className="gap-2">
              <History className="h-4 w-4" />
              My Reservations
            </TabsTrigger>
            <TabsTrigger value="safety" className="gap-2">
              <ShieldCheck className="h-4 w-4" />
              Safety Guidelines
            </TabsTrigger>
          </TabsList>

          <TabsContent value="discover">
            <AvailableFoodGrid listings={listings} onReserve={handleReserve} />
          </TabsContent>

          <TabsContent value="reservations">
            <UserReservations reservations={reservations} listings={listings} />
          </TabsContent>

          <TabsContent value="safety">
            <SafetyGuidelines />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
