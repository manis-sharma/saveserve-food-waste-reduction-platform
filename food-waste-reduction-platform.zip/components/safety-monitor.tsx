"use client"

import { useEffect } from "react"
import { loadFoodListings, saveFoodListings } from "@/lib/storage"

/**
 * Safety Monitor - Automatic expiry enforcement
 * This component runs safety checks in the background
 * Restaurants CANNOT override these automated safety rules
 */
export function SafetyMonitor() {
  useEffect(() => {
    // Run safety checks every minute
    const interval = setInterval(() => {
      const listings = loadFoodListings()
      const now = new Date()
      let hasChanges = false

      const updatedListings = listings.map((listing) => {
        // Auto-expire based on time
        if (listing.status === "active" && listing.consumeBefore <= now) {
          console.log(`[v0] Auto-expiring food: ${listing.foodName} (expired at ${listing.consumeBefore})`)
          hasChanges = true
          return { ...listing, status: "expired" as const }
        }

        // Additional safety checks
        if (listing.status === "active") {
          // Check if prepared time is in future (invalid)
          if (listing.preparedAt > now) {
            console.log(`[v0] Removing invalid listing: ${listing.foodName} (future preparation time)`)
            hasChanges = true
            return { ...listing, status: "removed" as const, safetyVerified: false }
          }

          // Check if consume before is before prepared (invalid)
          if (listing.consumeBefore <= listing.preparedAt) {
            console.log(
              `[v0] Removing invalid listing: ${listing.foodName} (consume before is before preparation time)`,
            )
            hasChanges = true
            return { ...listing, status: "removed" as const, safetyVerified: false }
          }
        }

        return listing
      })

      if (hasChanges) {
        saveFoodListings(updatedListings)
        console.log("[v0] Safety automation: Updated listings with expired/invalid items")
      }
    }, 60000) // Check every minute

    // Run immediately on mount
    const initialCheck = () => {
      const listings = loadFoodListings()
      const now = new Date()
      const updatedListings = listings.map((listing) => {
        if (listing.status === "active" && listing.consumeBefore <= now) {
          return { ...listing, status: "expired" as const }
        }
        return listing
      })
      saveFoodListings(updatedListings)
    }
    initialCheck()

    return () => clearInterval(interval)
  }, [])

  return null // This component runs in the background
}
