"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { FoodListing } from "@/lib/types"
import { TrendingUp, Package, Clock, Users } from "lucide-react"

interface RestaurantAnalyticsProps {
  listings: FoodListing[]
}

export function RestaurantAnalytics({ listings }: RestaurantAnalyticsProps) {
  // Calculate analytics
  const totalListings = listings.length
  const activeListings = listings.filter((l) => l.status === "active").length
  const collectedListings = listings.filter((l) => l.status === "collected").length
  const expiredListings = listings.filter((l) => l.status === "expired").length

  // Most wasted items
  const foodCounts: Record<string, number> = {}
  listings.forEach((food) => {
    foodCounts[food.foodName] = (foodCounts[food.foodName] || 0) + 1
  })
  const topWastedFoods = Object.entries(foodCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)

  // Peak times
  const hourCounts: Record<number, number> = {}
  listings.forEach((food) => {
    const hour = food.preparedAt.getHours()
    hourCounts[hour] = (hourCounts[hour] || 0) + 1
  })
  const peakHour = Object.entries(hourCounts).sort(([, a], [, b]) => b - a)[0]

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Package className="h-4 w-4" />
              Total Listed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalListings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Successfully Collected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{collectedListings}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {totalListings > 0 ? Math.round((collectedListings / totalListings) * 100) : 0}% success rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Expired
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-muted-foreground">{expiredListings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4" />
              Currently Active
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">{activeListings}</div>
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Most Listed Foods</CardTitle>
            <CardDescription>Items you list most frequently</CardDescription>
          </CardHeader>
          <CardContent>
            {topWastedFoods.length > 0 ? (
              <div className="space-y-3">
                {topWastedFoods.map(([name, count], index) => (
                  <div key={name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="font-medium text-sm">{index + 1}.</div>
                      <div>
                        <div className="font-medium">{name}</div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">{count} times</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Peak Surplus Time</CardTitle>
            <CardDescription>When you generate most surplus food</CardDescription>
          </CardHeader>
          <CardContent>
            {peakHour ? (
              <div className="space-y-4">
                <div>
                  <div className="text-3xl font-bold">{peakHour[0]}:00</div>
                  <p className="text-sm text-muted-foreground mt-1">Most listings created at this hour</p>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm font-medium mb-2">Recommendation</p>
                  <p className="text-sm text-muted-foreground">
                    Consider adjusting preparation quantities around this time to reduce waste.
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data yet</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Actionable Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Waste Reduction Insights</CardTitle>
          <CardDescription>Data-driven recommendations to improve planning</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-3 p-4 border rounded-lg">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="font-medium text-sm">High Success Rate</p>
              <p className="text-sm text-muted-foreground">
                {collectedListings} out of {totalListings} listings were successfully collected. Keep up the great work!
              </p>
            </div>
          </div>

          {expiredListings > totalListings * 0.3 && (
            <div className="flex gap-3 p-4 border rounded-lg border-accent/20 bg-accent/5">
              <div className="h-8 w-8 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                <Clock className="h-4 w-4 text-accent" />
              </div>
              <div>
                <p className="font-medium text-sm">High Expiry Rate</p>
                <p className="text-sm text-muted-foreground">
                  Consider setting longer pickup windows or promoting listings earlier to reduce expiries.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
