"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"

export function RegisterForm() {
  const [loading, setLoading] = useState(false)
  const [userType, setUserType] = useState<"individual" | "restaurant" | "ngo">("individual")
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)

    // Simulate registration
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setSuccess(true)
    setLoading(false)

    setTimeout(() => {
      router.push("/login")
    }, 2000)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl">Join SaveServe</CardTitle>
        <CardDescription>Create an account to start reducing food waste</CardDescription>
      </CardHeader>
      <CardContent>
        {success ? (
          <Alert className="border-primary/20 bg-primary/5">
            <AlertDescription>
              Registration successful! Redirecting to login...
              <br />
              <span className="text-xs text-muted-foreground mt-1 block">
                Use demo credentials to explore the platform
              </span>
            </AlertDescription>
          </Alert>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userType">I want to register as</Label>
              <Select
                value={userType}
                onValueChange={(v) => setUserType(v as "individual" | "restaurant" | "ngo")}
                required
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="individual">Individual (Collect Food)</SelectItem>
                  <SelectItem value="restaurant">Restaurant (Donate Food)</SelectItem>
                  <SelectItem value="ngo">NGO (Bulk Collection)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">
                {userType === "restaurant" ? "Restaurant Name" : userType === "ngo" ? "NGO Name" : "Full Name"}
              </Label>
              <Input
                id="name"
                name="name"
                placeholder={
                  userType === "restaurant"
                    ? "Delicious Eats"
                    : userType === "ngo"
                      ? "Food Relief Foundation"
                      : "John Doe"
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" placeholder="you@example.com" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" name="phone" type="tel" placeholder="+91-XXXX-XXXX-XX" required />
            </div>

            {(userType === "restaurant" || userType === "ngo") && (
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input id="address" name="address" placeholder="Street, City" required />
              </div>
            )}

            {userType === "restaurant" && (
              <div className="space-y-2">
                <Label htmlFor="license">License Number (Optional)</Label>
                <Input id="license" name="license" placeholder="FSSAI or equivalent" />
              </div>
            )}

            {userType === "ngo" && (
              <div className="space-y-2">
                <Label htmlFor="registration">Registration Number (Optional)</Label>
                <Input id="registration" name="registration" placeholder="NGO registration number" />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" name="password" type="password" minLength={6} required />
            </div>

            <div className="text-xs text-muted-foreground">
              By registering, you agree to our{" "}
              <Link href="/terms" className="text-primary hover:underline">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="text-primary hover:underline">
                Privacy Policy
              </Link>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating account...
                </>
              ) : (
                "Create Account"
              )}
            </Button>

            <div className="text-center text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </div>
          </form>
        )}

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <p className="text-xs font-medium mb-2">For demo, use existing accounts:</p>
          <div className="text-xs space-y-1 text-muted-foreground">
            <p>Restaurant: restaurant@demo.com / demo123</p>
            <p>Individual: user@demo.com / demo123</p>
            <p>NGO: ngo@demo.com / demo123</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
