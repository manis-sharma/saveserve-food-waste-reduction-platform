"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FoodCard } from "./food-card"
import type { FoodListing } from "@/lib/types"
import { Search, SlidersHorizontal, X } from "lucide-react"

interface AvailableFoodGridProps {
  listings: FoodListing[]
  onReserve: (food: FoodListing) => void
}

export function AvailableFoodGrid({ listings, onReserve }: AvailableFoodGridProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [filterDonation, setFilterDonation] = useState<string>("all")
  const [showFilters, setShowFilters] = useState(false)

  // Filter listings
  const filteredListings = listings.filter((food) => {
    const matchesSearch =
      food.foodName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      food.restaurantName.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = filterType === "all" || food.foodType === filterType

    const matchesDonation =
      filterDonation === "all" ||
      (filterDonation === "donation" && food.isDonation) ||
      (filterDonation === "discounted" && !food.isDonation)

    return matchesSearch && matchesType && matchesDonation
  })

  const clearFilters = () => {
    setSearchTerm("")
    setFilterType("all")
    setFilterDonation("all")
  }

  const hasActiveFilters = searchTerm || filterType !== "all" || filterDonation !== "all"

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg">
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search by food name or restaurant..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-11 h-12 rounded-full border-2 focus:border-primary transition-colors"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <Button
                variant={showFilters ? "default" : "outline"}
                onClick={() => setShowFilters(!showFilters)}
                className="gap-2 h-12 px-6 rounded-full"
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filters
              </Button>
            </div>

            {showFilters && (
              <div className="grid gap-4 md:grid-cols-2 pt-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-foreground">Food Type</label>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="h-11 rounded-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="cooked">Cooked</SelectItem>
                      <SelectItem value="baked">Baked</SelectItem>
                      <SelectItem value="prepared">Prepared</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-foreground">Availability</label>
                  <Select value={filterDonation} onValueChange={setFilterDonation}>
                    <SelectTrigger className="h-11 rounded-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="donation">Free Donation</SelectItem>
                      <SelectItem value="discounted">Discounted</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {hasActiveFilters && (
              <div className="flex items-center justify-between pt-2">
                <p className="text-sm text-muted-foreground">Active filters applied</p>
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-primary hover:text-primary/80">
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold">
              {filteredListings.length} {filteredListings.length === 1 ? "Item" : "Items"}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">Fresh food available for collection</p>
          </div>
        </div>

        {filteredListings.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredListings.map((food) => (
              <FoodCard key={food.id} food={food} showActions onReserve={onReserve} />
            ))}
          </div>
        ) : (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No food items found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search terms, or check back later for new listings.
              </p>
              {hasActiveFilters && (
                <Button onClick={clearFilters} variant="outline" className="rounded-full bg-transparent">
                  Clear all filters
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
