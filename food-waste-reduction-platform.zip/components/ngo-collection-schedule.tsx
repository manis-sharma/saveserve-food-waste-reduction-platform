"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { FoodRequest, FoodListing } from "@/lib/types"
import { Calendar, MapPin, Clock, Package, CheckCircle2 } from "lucide-react"

interface NGOCollectionScheduleProps {
  requests: FoodRequest[]
  listings: FoodListing[]
}

export function NGOCollectionSchedule({ requests, listings }: NGOCollectionScheduleProps) {
  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
          <p>No scheduled collections.</p>
          <p className="text-sm mt-2">Submit bulk requests to schedule pickups.</p>
        </CardContent>
      </Card>
    )
  }

  // Group by pickup time
  const groupedByDate: Record<string, FoodRequest[]> = {}
  requests.forEach((request) => {
    if (request.pickupTime) {
      const dateKey = request.pickupTime.toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
      })
      if (!groupedByDate[dateKey]) {
        groupedByDate[dateKey] = []
      }
      groupedByDate[dateKey].push(request)
    }
  })

  return (
    <div className="space-y-6">
      {Object.entries(groupedByDate).map(([date, dateRequests]) => (
        <Card key={date}>
          <CardContent className="py-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              {date}
            </h3>
            <div className="space-y-3">
              {dateRequests.map((request) => {
                const food = listings.find((l) => l.id === request.foodListingId)
                if (!food) return null

                return (
                  <Card key={request.id} className="border-l-4 border-l-primary">
                    <CardContent className="py-4">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-semibold">{food.foodName}</h4>
                            <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                              <MapPin className="h-3 w-3" />
                              {food.restaurantName}
                            </p>
                          </div>
                          <Badge variant="default">Approved</Badge>
                        </div>

                        <div className="grid gap-2 text-sm">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>
                              Pickup Time:{" "}
                              {request.pickupTime?.toLocaleTimeString("en-US", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Package className="h-4 w-4" />
                            <span>Quantity: {food.quantity}</span>
                          </div>
                        </div>

                        <div className="pt-3 border-t bg-muted/50 p-3 rounded-lg text-sm">
                          <p className="font-medium mb-1">Collection Details:</p>
                          <p className="text-muted-foreground">
                            <strong>Location:</strong> {food.restaurantName}
                          </p>
                          <p className="text-muted-foreground">
                            <strong>Contact:</strong> +91-XXXX-XXXX-XX
                          </p>
                          <p className="text-xs text-muted-foreground mt-2">
                            Bring NGO credentials and vehicle for bulk collection
                          </p>
                        </div>

                        <Button className="w-full gap-2 bg-transparent" variant="outline">
                          <CheckCircle2 className="h-4 w-4" />
                          Mark as Collected
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
