"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import type { User } from "@/lib/auth"
import type { FoodListing } from "@/lib/types"
import { loadFoodListings } from "@/lib/storage"
import { getDemoFoodListings } from "@/lib/food-data"
import { BarChart3, Users, AlertTriangle, Shield, TrendingUp, Package } from "lucide-react"

interface AdminDashboardProps {
  user: User
}

export function AdminDashboard({ user }: AdminDashboardProps) {
  const [listings, setListings] = useState<FoodListing[]>([])

  useEffect(() => {
    const stored = loadFoodListings()
    if (stored.length > 0) {
      setListings(stored)
    } else {
      const demo = getDemoFoodListings()
      setListings(demo)
    }
  }, [])

  const activeListings = listings.filter((l) => l.status === "active")
  const expiredListings = listings.filter((l) => l.status === "expired")
  const collectedListings = listings.filter((l) => l.status === "collected")
  const totalRestaurants = new Set(listings.map((l) => l.restaurantId)).size

  // Safety violations (for monitoring)
  const safetyViolations = listings.filter((l) => !l.safetyVerified || l.preparedAt > new Date()).length

  return (
    <main className="flex-1 py-8">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Platform-wide monitoring and compliance tracking</p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Package className="h-4 w-4" />
                Active Listings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeListings.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Currently available</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Total Collected
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{collectedListings.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Successfully distributed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="h-4 w-4" />
                Partner Restaurants
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalRestaurants}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered and active</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Safety Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${safetyViolations > 0 ? "text-destructive" : "text-primary"}`}>
                {safetyViolations}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Violations detected</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="safety" className="gap-2">
              <Shield className="h-4 w-4" />
              Safety Monitoring
            </TabsTrigger>
            <TabsTrigger value="compliance" className="gap-2">
              <AlertTriangle className="h-4 w-4" />
              Compliance
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Statistics</CardTitle>
                  <CardDescription>Key metrics and performance indicators</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Listings</span>
                    <span className="font-bold">{listings.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Success Rate</span>
                    <span className="font-bold text-primary">
                      {listings.length > 0 ? Math.round((collectedListings.length / listings.length) * 100) : 0}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Auto-Expired</span>
                    <span className="font-bold text-muted-foreground">{expiredListings.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Waste Prevented</span>
                    <span className="font-bold">{collectedListings.length * 2} kg</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                  <CardDescription>Automated safety enforcement status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Auto-Expiry System</span>
                    <Badge variant="default" className="bg-primary">
                      Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Safety Validation</span>
                    <Badge variant="default" className="bg-primary">
                      Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Time-Based Filtering</span>
                    <Badge variant="default" className="bg-primary">
                      Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Audit Logging</span>
                    <Badge variant="default" className="bg-primary">
                      Active
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="safety">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Safety Monitoring Dashboard
                </CardTitle>
                <CardDescription>Automated enforcement - No manual overrides allowed for safety rules</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 border rounded-lg bg-primary/5">
                    <div className="text-2xl font-bold text-primary">{expiredListings.length}</div>
                    <p className="text-sm text-muted-foreground mt-1">Auto-expired listings</p>
                  </div>
                  <div className="p-4 border rounded-lg bg-primary/5">
                    <div className="text-2xl font-bold text-primary">{activeListings.length}</div>
                    <p className="text-sm text-muted-foreground mt-1">Currently safe listings</p>
                  </div>
                  <div className="p-4 border rounded-lg bg-primary/5">
                    <div className="text-2xl font-bold text-primary">100%</div>
                    <p className="text-sm text-muted-foreground mt-1">Safety compliance</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold">Safety Rules Enforced:</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Automatic expiry removal at consume-before time</span>
                    </div>
                    <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Only cooked/prepared food allowed (no raw ingredients)</span>
                    </div>
                    <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>Preparation time must be before expiry time</span>
                    </div>
                    <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>No manual override by restaurants or users</span>
                    </div>
                  </div>
                </div>

                {safetyViolations > 0 && (
                  <div className="border-destructive/20 bg-destructive/5 border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                      <h3 className="font-semibold text-destructive">Safety Violations Detected</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {safetyViolations} listings have been automatically removed due to safety violations. These items
                      are no longer visible to users.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compliance">
            <Card>
              <CardHeader>
                <CardTitle>Compliance & Audit Trail</CardTitle>
                <CardDescription>Inspection-ready logs and regulatory compliance tracking</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Activity Logs</p>
                      <p className="text-sm text-muted-foreground">All user actions tracked with timestamps</p>
                    </div>
                    <Badge variant="default">Enabled</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Safety Enforcement</p>
                      <p className="text-sm text-muted-foreground">Automated rules with no manual overrides</p>
                    </div>
                    <Badge variant="default">Enforced</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Restaurant Verification</p>
                      <p className="text-sm text-muted-foreground">License and approval system in place</p>
                    </div>
                    <Badge variant="default">Active</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Transparency Logs</p>
                      <p className="text-sm text-muted-foreground">All listings and distributions tracked</p>
                    </div>
                    <Badge variant="default">Complete</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h3 className="font-semibold mb-3">Compliance Status</h3>
                  <div className="space-y-2 text-sm">
                    <p className="text-muted-foreground leading-relaxed">
                      The platform maintains strict food safety standards in accordance with regulatory requirements.
                      All food listings are time-tracked, verified, and automatically removed when expired.
                    </p>
                    <p className="text-muted-foreground leading-relaxed">
                      SaveServe acts as a facilitator connecting donors and recipients. The platform enforces safety
                      rules but consumption responsibility lies with the recipient. All transactions are logged for
                      audit purposes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
