"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddFoodForm } from "./add-food-form"
import { ManageFoodListings } from "./manage-food-listings"
import { RestaurantAnalytics } from "./restaurant-analytics"
import type { User } from "@/lib/auth"
import type { FoodListing } from "@/lib/types"
import { loadFoodListings, saveFoodListings } from "@/lib/storage"
import { getDemoFoodListings } from "@/lib/food-data"
import { Plus, BarChart3, List } from "lucide-react"

interface RestaurantDashboardProps {
  user: User
}

export function RestaurantDashboard({ user }: RestaurantDashboardProps) {
  const [listings, setListings] = useState<FoodListing[]>([])
  const [showAddForm, setShowAddForm] = useState(false)

  useEffect(() => {
    // Load listings from storage or use demo data
    const stored = loadFoodListings()
    if (stored.length > 0) {
      setListings(stored)
    } else {
      const demo = getDemoFoodListings()
      setListings(demo)
      saveFoodListings(demo)
    }
  }, [])

  const restaurantListings = listings.filter((l) => l.restaurantId === user.id)
  const activeListings = restaurantListings.filter((l) => l.status === "active")
  const expiredListings = restaurantListings.filter((l) => l.status === "expired")

  const handleAddFood = (newFood: Omit<FoodListing, "id" | "restaurantId" | "restaurantName" | "createdAt">) => {
    const food: FoodListing = {
      ...newFood,
      id: `food-${Date.now()}`,
      restaurantId: user.id,
      restaurantName: user.name,
      createdAt: new Date(),
    }

    const updatedListings = [...listings, food]
    setListings(updatedListings)
    saveFoodListings(updatedListings)
    setShowAddForm(false)
  }

  const handleUpdateFood = (id: string, updates: Partial<FoodListing>) => {
    const updatedListings = listings.map((l) => (l.id === id ? { ...l, ...updates } : l))
    setListings(updatedListings)
    saveFoodListings(updatedListings)
  }

  const handleRemoveFood = (id: string) => {
    const updatedListings = listings.map((l) => (l.id === id ? { ...l, status: "removed" as const } : l))
    setListings(updatedListings)
    saveFoodListings(updatedListings)
  }

  return (
    <main className="flex-1 py-8">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Restaurant Dashboard</h1>
          <p className="text-muted-foreground">Manage your surplus food listings and track impact</p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Listings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeListings.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Listed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{restaurantListings.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Expired Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{expiredListings.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Impact Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">92%</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="listings" className="space-y-6">
          <TabsList>
            <TabsTrigger value="listings" className="gap-2">
              <List className="h-4 w-4" />
              My Listings
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="listings" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Food Listings Management</CardTitle>
                    <CardDescription>Add, update, or remove your surplus food listings</CardDescription>
                  </div>
                  <Button onClick={() => setShowAddForm(!showAddForm)} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Food
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {showAddForm && (
                  <div className="border rounded-lg p-6 bg-muted/30">
                    <h3 className="text-lg font-semibold mb-4">Add New Food Listing</h3>
                    <AddFoodForm onSubmit={handleAddFood} onCancel={() => setShowAddForm(false)} />
                  </div>
                )}

                <div>
                  <h3 className="text-lg font-semibold mb-4">Current Listings</h3>
                  <ManageFoodListings
                    listings={restaurantListings}
                    onUpdate={handleUpdateFood}
                    onRemove={handleRemoveFood}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Safety Guidelines */}
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-base">Food Safety Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>• Only list freshly cooked or prepared food (no raw ingredients)</p>
                <p>• Set realistic consumption windows based on food type</p>
                <p>• Food is automatically removed when expired - no manual override</p>
                <p>• Maintain accurate preparation times for safety tracking</p>
                <p>• You cannot modify system safety rules or expiry automation</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <RestaurantAnalytics listings={restaurantListings} />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
