"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { FoodListing } from "@/lib/types"
import { Clock, AlertCircle, Trash2 } from "lucide-react"

interface ManageFoodListingsProps {
  listings: FoodListing[]
  onUpdate: (id: string, updates: Partial<FoodListing>) => void
  onRemove: (id: string) => void
}

export function ManageFoodListings({ listings, onUpdate, onRemove }: ManageFoodListingsProps) {
  if (listings.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <p>No food listings yet. Add your first listing to get started.</p>
        </CardContent>
      </Card>
    )
  }

  const activeListings = listings.filter((l) => l.status === "active")
  const inactiveListings = listings.filter((l) => l.status !== "active")

  return (
    <div className="space-y-6">
      {activeListings.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-sm text-muted-foreground">Active ({activeListings.length})</h4>
          <div className="space-y-3">
            {activeListings.map((food) => (
              <FoodListingCard key={food.id} food={food} onRemove={onRemove} />
            ))}
          </div>
        </div>
      )}

      {inactiveListings.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-sm text-muted-foreground">Inactive ({inactiveListings.length})</h4>
          <div className="space-y-3">
            {inactiveListings.map((food) => (
              <FoodListingCard key={food.id} food={food} onRemove={onRemove} inactive />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function FoodListingCard({
  food,
  onRemove,
  inactive = false,
}: {
  food: FoodListing
  onRemove: (id: string) => void
  inactive?: boolean
}) {
  const now = new Date()
  const timeUntilExpiry = Math.floor((food.consumeBefore.getTime() - now.getTime()) / (1000 * 60))
  const hoursUntilExpiry = Math.floor(timeUntilExpiry / 60)
  const minutesUntilExpiry = timeUntilExpiry % 60

  return (
    <Card className={inactive ? "opacity-60" : ""}>
      <CardContent className="py-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-semibold">{food.foodName}</h4>
              <Badge variant={food.status === "active" ? "default" : "secondary"}>{food.status}</Badge>
              {food.isDonation ? (
                <Badge variant="outline" className="bg-primary/10 text-primary">
                  Free
                </Badge>
              ) : (
                <Badge variant="outline">Rs {food.discountedPrice}</Badge>
              )}
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <span>Quantity: {food.quantity}</span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Prepared:{" "}
                {food.preparedAt.toLocaleString("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
            </div>

            {food.status === "active" && timeUntilExpiry > 0 && (
              <div className="flex items-center gap-1 text-sm">
                <AlertCircle className="h-3 w-3 text-accent" />
                <span className="font-medium text-accent">
                  Expires in: {hoursUntilExpiry}h {minutesUntilExpiry}m
                </span>
              </div>
            )}

            {food.status === "expired" && (
              <div className="flex items-center gap-1 text-sm text-destructive">
                <AlertCircle className="h-3 w-3" />
                <span className="font-medium">Expired - Auto-removed from public view</span>
              </div>
            )}
          </div>

          {food.status === "active" && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onRemove(food.id)}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
