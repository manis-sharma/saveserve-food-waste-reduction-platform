"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { FoodRequest, FoodListing } from "@/lib/types"
import { TrendingUp, Users, Package, Calendar } from "lucide-react"

interface NGOReportsProps {
  requests: FoodRequest[]
  listings: FoodListing[]
}

export function NGOReports({ requests, listings }: NGOReportsProps) {
  // Calculate metrics
  const totalCollected = requests.filter((r) => r.status === "collected").length
  const estimatedMeals = totalCollected * 15
  const uniqueRestaurants = new Set(
    requests.map((r) => listings.find((l) => l.id === r.foodListingId)?.restaurantId).filter((id) => id !== undefined),
  ).size

  // Monthly trend
  const currentMonth = new Date().getMonth()
  const thisMonthCollections = requests.filter((r) => r.createdAt.getMonth() === currentMonth).length

  // Most collected items
  const foodCounts: Record<string, number> = {}
  requests.forEach((request) => {
    const food = listings.find((l) => l.id === request.foodListingId)
    if (food) {
      foodCounts[food.foodName] = (foodCounts[food.foodName] || 0) + 1
    }
  })
  const topCollectedFoods = Object.entries(foodCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Overview Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Package className="h-4 w-4" />
              Total Collections
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCollected}</div>
            <p className="text-xs text-muted-foreground mt-1">All time</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4" />
              Meals Served
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{estimatedMeals}</div>
            <p className="text-xs text-muted-foreground mt-1">Estimated impact</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              This Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">{thisMonthCollections}</div>
            <p className="text-xs text-muted-foreground mt-1">Collections</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Partner Restaurants
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{uniqueRestaurants}</div>
            <p className="text-xs text-muted-foreground mt-1">Food sources</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Most Collected Items</CardTitle>
            <CardDescription>Top food items distributed to community</CardDescription>
          </CardHeader>
          <CardContent>
            {topCollectedFoods.length > 0 ? (
              <div className="space-y-3">
                {topCollectedFoods.map(([name, count], index) => (
                  <div key={name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="font-medium text-sm">{index + 1}.</div>
                      <div>
                        <div className="font-medium">{name}</div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">{count} times</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Social Impact</CardTitle>
            <CardDescription>Measurable community benefit</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Food Waste Prevented</span>
                <span className="font-bold">{totalCollected * 2} kg</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Families Helped</span>
                <span className="font-bold">{Math.floor(estimatedMeals / 4)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">CO2 Emissions Saved</span>
                <span className="font-bold">{totalCollected * 3.5} kg</span>
              </div>
            </div>

            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Your NGO has made a significant impact by redistributing surplus food to those in need while preventing
                environmental waste.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Compliance Section */}
      <Card>
        <CardHeader>
          <CardTitle>Compliance & Audit Readiness</CardTitle>
          <CardDescription>Documentation for regulatory requirements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Distribution Logs</p>
              <p className="text-sm text-muted-foreground">Complete record of all collections</p>
            </div>
            <Package className="h-5 w-5 text-primary" />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Partner Verification</p>
              <p className="text-sm text-muted-foreground">All restaurants verified and licensed</p>
            </div>
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Time Tracking</p>
              <p className="text-sm text-muted-foreground">Timestamps for all collection activities</p>
            </div>
            <Calendar className="h-5 w-5 text-primary" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
