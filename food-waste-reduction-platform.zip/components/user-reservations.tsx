"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { FoodRequest, FoodListing } from "@/lib/types"
import { Clock, MapPin, Calendar, Package } from "lucide-react"

interface UserReservationsProps {
  reservations: FoodRequest[]
  listings: FoodListing[]
}

export function UserReservations({ reservations, listings }: UserReservationsProps) {
  if (reservations.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
          <p>No reservations yet.</p>
          <p className="text-sm mt-2">Browse available food and make your first reservation!</p>
        </CardContent>
      </Card>
    )
  }

  const activeReservations = reservations.filter((r) => r.status === "pending" || r.status === "approved")
  const completedReservations = reservations.filter((r) => r.status === "collected")
  const cancelledReservations = reservations.filter((r) => r.status === "cancelled")

  return (
    <div className="space-y-6">
      {activeReservations.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Active Reservations ({activeReservations.length})</h3>
          <div className="space-y-3">
            {activeReservations.map((reservation) => {
              const food = listings.find((l) => l.id === reservation.foodListingId)
              return <ReservationCard key={reservation.id} reservation={reservation} food={food} />
            })}
          </div>
        </div>
      )}

      {completedReservations.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Collection History ({completedReservations.length})</h3>
          <div className="space-y-3">
            {completedReservations.map((reservation) => {
              const food = listings.find((l) => l.id === reservation.foodListingId)
              return <ReservationCard key={reservation.id} reservation={reservation} food={food} />
            })}
          </div>
        </div>
      )}

      {cancelledReservations.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-muted-foreground">Cancelled ({cancelledReservations.length})</h3>
          <div className="space-y-3">
            {cancelledReservations.map((reservation) => {
              const food = listings.find((l) => l.id === reservation.foodListingId)
              return <ReservationCard key={reservation.id} reservation={reservation} food={food} />
            })}
          </div>
        </div>
      )}
    </div>
  )
}

function ReservationCard({ reservation, food }: { reservation: FoodRequest; food?: FoodListing }) {
  if (!food) {
    return (
      <Card className="opacity-60">
        <CardContent className="py-4">
          <p className="text-sm text-muted-foreground">Food listing not found</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="py-4">
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h4 className="font-semibold">{food.foodName}</h4>
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                <MapPin className="h-3 w-3" />
                {food.restaurantName}
              </p>
            </div>
            <Badge
              variant={
                reservation.status === "approved"
                  ? "default"
                  : reservation.status === "collected"
                    ? "secondary"
                    : "outline"
              }
            >
              {reservation.status}
            </Badge>
          </div>

          <div className="grid gap-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Package className="h-4 w-4" />
              <span>Quantity: {reservation.quantityRequested}</span>
            </div>

            {reservation.pickupTime && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="h-4 w-4" />
                <span>
                  Pickup:{" "}
                  {reservation.pickupTime.toLocaleString("en-US", {
                    month: "short",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            )}

            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>
                Reserved:{" "}
                {reservation.createdAt.toLocaleString("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
            </div>
          </div>

          {reservation.status === "approved" && (
            <div className="pt-3 border-t space-y-2">
              <p className="text-sm font-medium">Pickup Instructions:</p>
              <div className="bg-muted p-3 rounded-lg text-sm space-y-1">
                <p>
                  <strong>Address:</strong> {food.restaurantName}
                </p>
                <p>
                  <strong>Contact:</strong> Available after approval
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Please arrive on time and bring your own container. Show this reservation to collect your food.
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
