"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { FoodListing } from "@/lib/types"
import { Clock, Users, CheckCircle2, MapPin } from "lucide-react"
import { useState, useEffect } from "react"

interface FoodCardProps {
  food: FoodListing
  showActions?: boolean
  onReserve?: (food: FoodListing) => void
}

export function FoodCard({ food, showActions = false, onReserve }: FoodCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [timeUntilExpiry, setTimeUntilExpiry] = useState(0)

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const minutes = Math.floor((food.consumeBefore.getTime() - now.getTime()) / (1000 * 60))
      setTimeUntilExpiry(minutes)
    }

    updateTime()
    const interval = setInterval(updateTime, 60000) // Update every minute
    return () => clearInterval(interval)
  }, [food.consumeBefore])

  const hoursUntilExpiry = Math.floor(timeUntilExpiry / 60)
  const minutesUntilExpiry = timeUntilExpiry % 60

  const getTimeColor = () => {
    if (timeUntilExpiry < 60) return "destructive"
    if (timeUntilExpiry < 120) return "default"
    return "default"
  }

  const getTimeTextColor = () => {
    if (timeUntilExpiry < 60) return "text-red-600"
    if (timeUntilExpiry < 120) return "text-orange-600"
    return "text-green-600"
  }

  const foodImageQuery = `${food.foodName} indian food dish plate restaurant high quality`

  return (
    <Card className="group relative overflow-hidden rounded-3xl transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 border-0 shadow-lg bg-card">
      <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-muted via-muted to-muted/80">
        {/* Skeleton loader */}
        {!imageLoaded && (
          <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-muted via-muted-foreground/5 to-muted" />
        )}

        {/* Food image */}
        <img
          src={`/.jpg?height=500&width=600&query=${encodeURIComponent(foodImageQuery)}`}
          alt={food.foodName}
          className={`h-full w-full object-cover transition-all duration-700 group-hover:scale-110 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

        <div className="absolute top-4 right-4 z-10">
          {food.isDonation ? (
            <Badge className="bg-gradient-to-br from-green-600 to-green-700 text-white border-0 shadow-xl px-5 py-2 text-base font-bold rounded-2xl backdrop-blur-sm">
              FREE
            </Badge>
          ) : (
            <Badge className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-0 shadow-xl px-5 py-2 text-base font-bold rounded-2xl backdrop-blur-sm">
              ₹{food.discountedPrice}
            </Badge>
          )}
        </div>

        {food.safetyVerified && (
          <div className="absolute top-4 left-4 z-10">
            <Badge className="bg-white/95 backdrop-blur-md text-green-700 border-0 shadow-lg px-3 py-1.5 text-xs font-semibold rounded-xl flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Verified
            </Badge>
          </div>
        )}

        <div className="absolute bottom-4 left-4 right-4 z-10">
          <Badge
            className={`${getTimeTextColor()} bg-white/95 backdrop-blur-md border-0 shadow-lg px-4 py-2 text-sm font-bold rounded-xl flex items-center gap-2 w-fit`}
          >
            <Clock className="h-4 w-4" />
            <span>
              {hoursUntilExpiry > 0 && `${hoursUntilExpiry}h `}
              {minutesUntilExpiry}m left
            </span>
          </Badge>
        </div>
      </div>

      <CardContent className="p-6 space-y-4">
        {/* Food title and restaurant - simplified */}
        <div className="space-y-2">
          <h3 className="font-bold text-2xl text-balance leading-tight line-clamp-2 text-foreground">
            {food.foodName}
          </h3>
          <p className="text-base text-muted-foreground font-medium flex items-center gap-2">
            <MapPin className="h-4 w-4 flex-shrink-0" />
            {food.restaurantName}
          </p>
        </div>

        <div className="flex items-center gap-6 text-sm text-muted-foreground pt-2">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Serves</p>
              <p className="font-bold text-foreground">{food.quantity}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Prepared</p>
              <p className="font-bold text-foreground">
                {food.preparedAt.toLocaleTimeString("en-US", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-green-50 border border-green-200">
          <CheckCircle2 className="h-4 w-4 text-green-700 flex-shrink-0" />
          <span className="text-xs font-semibold text-green-700">Safe to consume within time limit</span>
        </div>
      </CardContent>

      <CardFooter className="p-6 pt-0">
        {showActions ? (
          <Button
            className="w-full rounded-2xl py-6 text-base font-bold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] bg-gradient-to-r from-primary to-primary/90"
            onClick={() => onReserve?.(food)}
          >
            Reserve This Food
          </Button>
        ) : (
          <div className="w-full space-y-3">
            <Button className="w-full rounded-2xl py-6 text-base font-bold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] bg-gradient-to-r from-primary to-primary/90">
              Login to Collect Food
            </Button>
            <p className="text-xs text-center text-muted-foreground font-medium">
              Sign in to reserve and get pickup details
            </p>
          </div>
        )}
      </CardFooter>
    </Card>
  )
}
