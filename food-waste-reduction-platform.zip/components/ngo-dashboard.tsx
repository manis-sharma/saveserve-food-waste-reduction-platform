"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BulkFoodRequests } from "./bulk-food-requests"
import { NGOCollectionSchedule } from "./ngo-collection-schedule"
import { NGODistributionLogs } from "./ngo-distribution-logs"
import { NGOReports } from "./ngo-reports"
import type { User } from "@/lib/auth"
import type { FoodListing, FoodRequest } from "@/lib/types"
import { loadFoodListings } from "@/lib/storage"
import { getActiveFoodListings } from "@/lib/food-data"
import { Package, Calendar, FileText, TrendingUp } from "lucide-react"

interface NGODashboardProps {
  user: User
}

export function NGODashboard({ user }: NGODashboardProps) {
  const [listings, setListings] = useState<FoodListing[]>([])
  const [requests, setRequests] = useState<FoodRequest[]>([])

  useEffect(() => {
    // Load active listings
    const stored = loadFoodListings()
    if (stored.length > 0) {
      const active = stored.filter((l) => {
        const now = new Date()
        return l.status === "active" && l.consumeBefore > now && l.safetyVerified
      })
      setListings(active)
    } else {
      setListings(getActiveFoodListings())
    }

    // Load NGO requests
    const storedRequests = localStorage.getItem(`ngo_requests_${user.id}`)
    if (storedRequests) {
      try {
        const parsed = JSON.parse(storedRequests)
        setRequests(
          parsed.map((r: any) => ({
            ...r,
            pickupTime: r.pickupTime ? new Date(r.pickupTime) : undefined,
            createdAt: new Date(r.createdAt),
          })),
        )
      } catch {
        setRequests([])
      }
    }
  }, [user.id])

  const handleBulkRequest = (selectedListings: string[], notes: string) => {
    const newRequests: FoodRequest[] = selectedListings.map((listingId) => ({
      id: `ngo-req-${Date.now()}-${listingId}`,
      foodListingId: listingId,
      requesterId: user.id,
      requesterType: "ngo",
      quantityRequested: "Full quantity",
      status: "approved",
      pickupTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      createdAt: new Date(),
    }))

    const updatedRequests = [...requests, ...newRequests]
    setRequests(updatedRequests)
    localStorage.setItem(`ngo_requests_${user.id}`, JSON.stringify(updatedRequests))
  }

  const donationListings = listings.filter((l) => l.isDonation)
  const pendingRequests = requests.filter((r) => r.status === "pending" || r.status === "approved")
  const collectedRequests = requests.filter((r) => r.status === "collected")
  const totalMealsServed = collectedRequests.length * 15 // Estimate

  return (
    <main className="flex-1 py-8">
      <div className="container">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">NGO Dashboard</h1>
          <p className="text-muted-foreground">Manage bulk food collection and distribution tracking</p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Available Donations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{donationListings.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Free food items</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{pendingRequests.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Pending pickups</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Collected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent">{collectedRequests.length}</div>
              <p className="text-xs text-muted-foreground mt-1">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Meals Served</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{totalMealsServed}</div>
              <p className="text-xs text-muted-foreground mt-1">Estimated impact</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="requests" className="space-y-6">
          <TabsList>
            <TabsTrigger value="requests" className="gap-2">
              <Package className="h-4 w-4" />
              Bulk Requests
            </TabsTrigger>
            <TabsTrigger value="schedule" className="gap-2">
              <Calendar className="h-4 w-4" />
              Collection Schedule
            </TabsTrigger>
            <TabsTrigger value="distribution" className="gap-2">
              <FileText className="h-4 w-4" />
              Distribution Logs
            </TabsTrigger>
            <TabsTrigger value="reports" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="requests">
            <BulkFoodRequests listings={donationListings} onSubmitRequest={handleBulkRequest} />
          </TabsContent>

          <TabsContent value="schedule">
            <NGOCollectionSchedule requests={pendingRequests} listings={listings} />
          </TabsContent>

          <TabsContent value="distribution">
            <NGODistributionLogs requests={collectedRequests} listings={listings} />
          </TabsContent>

          <TabsContent value="reports">
            <NGOReports requests={requests} listings={listings} />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
