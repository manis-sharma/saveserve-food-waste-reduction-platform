"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { FoodListing } from "@/lib/types"
import { MapPin, Clock, AlertCircle, Package } from "lucide-react"

interface BulkFoodRequestsProps {
  listings: FoodListing[]
  onSubmitRequest: (selectedListings: string[], notes: string) => void
}

export function BulkFoodRequests({ listings, onSubmitRequest }: BulkFoodRequestsProps) {
  const [selectedListings, setSelectedListings] = useState<string[]>([])
  const [submitted, setSubmitted] = useState(false)

  const handleToggle = (id: string) => {
    setSelectedListings((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  const handleSubmit = () => {
    if (selectedListings.length > 0) {
      onSubmitRequest(selectedListings, "Bulk collection for community distribution")
      setSubmitted(true)
      setSelectedListings([])
      setTimeout(() => setSubmitted(false), 3000)
    }
  }

  if (listings.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
          <p>No donation items available at the moment.</p>
          <p className="text-sm mt-2">Check back soon for new food donations.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Bulk Food Collection</CardTitle>
          <CardDescription>Select multiple food items for consolidated pickup and distribution</CardDescription>
        </CardHeader>
        <CardContent>
          {submitted && (
            <Alert className="mb-6 border-primary/20 bg-primary/5">
              <AlertCircle className="h-4 w-4 text-primary" />
              <AlertDescription>
                Bulk request submitted successfully! Check the Collection Schedule tab for pickup details.
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-3">
            {listings.map((food) => {
              const now = new Date()
              const timeUntilExpiry = Math.floor((food.consumeBefore.getTime() - now.getTime()) / (1000 * 60))
              const hoursUntilExpiry = Math.floor(timeUntilExpiry / 60)
              const minutesUntilExpiry = timeUntilExpiry % 60
              const isSelected = selectedListings.includes(food.id)

              return (
                <Card key={food.id} className={isSelected ? "border-primary" : ""}>
                  <CardContent className="py-4">
                    <div className="flex items-start gap-4">
                      <Checkbox
                        id={food.id}
                        checked={isSelected}
                        onCheckedChange={() => handleToggle(food.id)}
                        className="mt-1"
                      />
                      <label htmlFor={food.id} className="flex-1 cursor-pointer space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="font-semibold">{food.foodName}</h4>
                            <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                              <MapPin className="h-3 w-3" />
                              {food.restaurantName}
                            </p>
                          </div>
                          <Badge variant="default" className="bg-primary text-primary-foreground">
                            Free
                          </Badge>
                        </div>

                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Package className="h-3 w-3" />
                            {food.quantity}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Expires in: {hoursUntilExpiry}h {minutesUntilExpiry}m
                          </span>
                        </div>
                      </label>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-6 pt-6 border-t">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="font-medium">{selectedListings.length} items selected</p>
                <p className="text-sm text-muted-foreground">These items will be scheduled for priority pickup</p>
              </div>
              <Button onClick={handleSubmit} disabled={selectedListings.length === 0} size="lg">
                Submit Bulk Request
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-base">NGO Priority Access</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• NGOs receive priority access to donated food for community distribution</p>
          <p>• Bulk requests can include multiple items from different restaurants</p>
          <p>• All food must be collected within the specified time window</p>
          <p>• Maintain distribution records for compliance and transparency</p>
        </CardContent>
      </Card>
    </div>
  )
}
